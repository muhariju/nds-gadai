package id.co.nds.gadai.globals;

public class GlobalConstant {
    public static final String REC_STATUS_ACTIVE = "A";
    public static final String REC_STATUS_NON_ACTIVE = "N";    
}
