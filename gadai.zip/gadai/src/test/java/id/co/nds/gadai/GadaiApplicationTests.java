package id.co.nds.gadai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GadaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
